package com.carsonmccombs.skillviewerfourcompose.statmodifier

import androidx.room.Dao

@Deprecated("Unneeded after transition to Relational Database, check out StatDao instead.")
@Dao
interface StatModifierDao {
    /*
    @Upsert
    suspend fun upsert(statModifier: StatModifier)

    @Delete
    suspend fun delete(statModifier: StatModifier)

    //@Query("SELECT * FROM statmodifier ORDER BY statID")
    //fun getAllStatModifiers():Flow<List<StatModifier>>


    //@Query("SELECT * FROM statmodifier WHERE statID LIKE :statID")
    //fun getStatModifiersByStatID(statID: Int): Flow<List<StatModifier>>

    //@Query("SELECT statID FROM statmodifier GROUP BY statID ORDER BY statID ASC")
    //fun getStatIDs():Flow<List<Int>>

    @Query("SELECT * FROM statmodifier WHERE statID LIKE :statID AND id LIKE :id")
    fun getStatModifier(statID: Int, id: Int): Flow<StatModifier>

    @Query("SELECT id FROM statmodifier WHERE statID LIKE :statID ORDER BY id ASC")
    fun getStatModifierIDs(statID: Int): Flow<List<Int>>
*/


}

