package com.carsonmccombs.skillviewerfourcompose.stat

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import com.carsonmccombs.skillviewerfourcompose.statmodifier.StatModifier
import com.carsonmccombs.skillviewerfourcompose.statmodifier_relationship.StatWithModifiers
import kotlinx.coroutines.flow.Flow

@Dao
interface StatDao {
    @Upsert
    suspend fun upsert(stat: Stat)

    @Delete
    suspend fun delete(stat: Stat)

    @Query("SELECT * FROM stat ORDER BY id ASC")
    fun getAllStats(): Flow<List<Stat>>

    @Query("SELECT * FROM stat WHERE id LIKE :id")
    fun getStat(id: Int): Flow<Stat>

    @Query("SELECT name FROM stat WHERE id LIKE :id")
    fun getStatName(id: Int): Flow<String>

    @Query("SELECT id FROM stat ORDER BY id")
    fun getStatIDs(): Flow<List<Int>>

    @Query("SELECT SUM (value) FROM statmodifier WHERE statID = :statID")
    fun getTotalStatModifiersValue(statID: Int): Flow<Int>

    @Transaction
    @Query("SELECT * FROM stat WHERE id = :id ORDER BY id ASC")
    fun getStatWithModifiers(id: Int): Flow<StatWithModifiers>

    @Transaction
    @Query("SELECT * FROM stat ORDER BY id ASC")
    fun getAllStatWithModifiers(): Flow<List<StatWithModifiers>>

    @Upsert
    suspend fun upsertStatModifier(statModifier: StatModifier)

    @Delete
    suspend fun deleteStatModifier(statModifier: StatModifier)


}