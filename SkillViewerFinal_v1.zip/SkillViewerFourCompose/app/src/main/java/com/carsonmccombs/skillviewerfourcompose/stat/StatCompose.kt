package com.carsonmccombs.skillviewerfourcompose.stat

import android.util.Log
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredHeightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FabPosition
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.carsonmccombs.skillviewerfourcompose.statmodifier.StatModifier
import com.carsonmccombs.skillviewerfourcompose.statmodifier.StatModifierCard
import com.carsonmccombs.skillviewerfourcompose.statmodifier_relationship.StatWithModifiers
import kotlinx.coroutines.flow.Flow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsContainer(statID: Int, getTotalStatModifierValue: (Int) -> Flow<Int>, getStatWithModifiers: (Int) -> Flow<StatWithModifiers>, onEvent: (StatEvent) -> Unit){
    val statWithModifiers: State<StatWithModifiers> = getStatWithModifiers(statID).collectAsState(StatWithModifiers())
    val stat = statWithModifiers.value.stat
    val statModifiers = statWithModifiers.value.modifiers

    val sumValue: State<Int?> = getTotalStatModifierValue(statID).collectAsState(initial = 0)

    val collapsedState = remember { mutableStateOf(false) }
    val minHeight = remember { mutableStateOf(100.dp) }
    val maxHeight = remember { mutableStateOf(400.dp) }
    when (collapsedState.value){
        true -> {
            minHeight.value = 60.dp
            maxHeight.value = 60.dp
        }

        false -> {
            minHeight.value = 100.dp
            maxHeight.value = 400.dp
        }

    }
    //val statModifierIDs: List<Int> = getStatModifierIDs(statID).collectAsState(initial = emptyList()).value
    Card(
        modifier = Modifier
            .padding(16.dp)
            .wrapContentHeight()
            .fillMaxWidth()
            .animateContentSize(
                animationSpec = tween(
                    durationMillis = 300,
                    easing = LinearOutSlowInEasing
                )
            ),
        colors = CardDefaults.cardColors(contentColor = MaterialTheme.colorScheme.onSecondary, containerColor = MaterialTheme.colorScheme.secondary),
        onClick = { collapsedState.value = !collapsedState.value }
    ) {

        Scaffold(
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .requiredHeightIn(min = minHeight.value, max = maxHeight.value),
            contentWindowInsets = WindowInsets(0.dp),
            topBar = { ModifierContainerTitle(stat, sumValue.value, onEvent) },
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.onSecondary,
            floatingActionButtonPosition = FabPosition.Center,
            floatingActionButton = {
                if (!collapsedState.value){
                    FloatingActionButton(
                        modifier = Modifier
                            .size(48.dp),
                        //.align(Alignment.CenterHorizontally),
                        onClick = {
                            Log.d("Twab", "NEW STATMOD at $statID")
                            onEvent(StatEvent.UpsertStatModifier(StatModifier(statID = statID)))
                        },
                        elevation = FloatingActionButtonDefaults.elevation(
                            defaultElevation = 16.dp,
                            pressedElevation = 4.dp,
                            focusedElevation = 12.dp,
                            hoveredElevation = 24.dp
                        ),
                        shape = CircleShape,
                        content = {

                            Icon(
                                imageVector = Icons.Default.AddCircle,
                                contentDescription = "Adds Modifier",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(1f)
                            )


                        }
                    )
                }

            },
        ){ padding ->
            if (!collapsedState.value){
                ModifierContainer(statModifiers = statModifiers, onEvent = onEvent, paddingValues = padding)
            }
        }



        }




}

@Composable
fun ModifierContainer(statModifiers: List<StatModifier>, onEvent: (StatEvent) -> Unit, paddingValues: PaddingValues){

    Column(
        modifier = Modifier.padding(top = 48.dp, bottom = 64.dp)
    ) {

        LazyColumn(modifier = Modifier
            .wrapContentHeight()
            .fillMaxWidth()
            .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ){
            items(items = statModifiers, itemContent = { mod -> StatModifierCard(mod, onEvent) })

        }
    }
}

@Composable
fun ModifierContainerTitle(stat: Stat, value: Int?, onEvent: (StatEvent) -> Unit){
    val nameState = remember { mutableStateOf(stat.name) }
    val editNameState = remember { mutableStateOf(true) }
    Card(
        modifier = Modifier
            .height(60.dp)
            .fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ){

        Row(
            modifier = Modifier.wrapContentSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ){

            TextField(
                enabled = editNameState.value,
                modifier = Modifier
                    .weight(1f)
                    .wrapContentSize(),

                //    .horizontalScroll(rememberScrollState()),
                value = nameState.value,
                onValueChange = {
                    if (it.length <= 18){
                        nameState.value = it.trimEnd('\n')
                        onEvent(StatEvent.Upsert(stat.copy(name = nameState.value)))
                    }
                },
                textStyle = MaterialTheme.typography.titleLarge,
                colors = TextFieldDefaults.colors(

                    unfocusedIndicatorColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    unfocusedTextColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    focusedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    focusedTextColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    disabledContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    disabledTextColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                singleLine = true,


            )
            Text(
                modifier = Modifier
                    .wrapContentSize()
                    .padding(end = 8.dp),
                text = "( +${value ?: 0} )",

            )
            Spacer(modifier = Modifier.weight(1f))


        }




    }
}
