package com.carsonmccombs.skillviewerfourcompose.statmodifier

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

@Deprecated("Unneeded after transition to relational database, check out StatViewModelFactory instead.")
class StatModifierViewModelFactory(private val dao: StatModifierDao): ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return StatModifierViewModel(dao) as T
    }
}