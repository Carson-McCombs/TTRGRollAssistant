@file:OptIn(ExperimentalMaterial3Api::class)

package com.carsonmccombs.skillviewerfourcompose.statmodifier

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.carsonmccombs.skillviewerfourcompose.stat.StatEvent

@Preview
@Composable
fun Preview_StatModifierCard(){
    StatModifierCard(statModifier = StatModifier(id = 0, statID = 0, name = "Mod_Name", type = "Mod_Type", value = 2), onEvent = { })
}

@Composable
fun StatModifierCard(statModifier: StatModifier, onEvent: (StatEvent) -> Unit){

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .requiredHeight(48.dp),
        //.background(MaterialTheme.colorScheme.primary),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)

    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            StatModifier_TextField_StringInput(
                modifier = Modifier.weight(1f),
                text = statModifier.name,
                onValueChangeEvent = { onEvent(StatEvent.UpsertStatModifier(statModifier = statModifier.copy(name = it))) },
                labelText = "Source"
            )
            StatModifier_TextField_StringInput(
                modifier = Modifier.weight(1f),
                text = statModifier.type,
                onValueChangeEvent = { onEvent(StatEvent.UpsertStatModifier(statModifier = statModifier.copy(type = it))) },
                labelText = "Type"
            )
            StatModifier_TextField_IntegerInput(
                modifier = Modifier.weight(1f),
                text = statModifier.value.toString(),
                onValueChangeEvent = { onEvent(StatEvent.UpsertStatModifier(statModifier = statModifier.copy(value = it))) },
                labelText = "Value"
            )

            IconButton(onClick = { onEvent(StatEvent.DeleteStatModifier(statModifier)) }) {
                Icon(
                    modifier = Modifier
                        .weight(0.5f),
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Deletes this Modifier"
                )
            }


        }
    }

}

@Composable
private fun StatModifier_TextField_StringInput(modifier: Modifier, text: String, labelText: String, textStyle: TextStyle = MaterialTheme.typography.labelSmall, onValueChangeEvent: (String) -> Unit){
    val state = remember { mutableStateOf(text) }
    TextField(
        modifier = modifier.horizontalScroll(rememberScrollState()),
        value = state.value,
        onValueChange = {newText ->
            state.value = newText.trimEnd('\n')
            onValueChangeEvent(state.value)
        },
        label = { Text(text = labelText, fontSize = 10.sp) },
        textStyle = textStyle,
        colors = TextFieldDefaults.colors(
            unfocusedIndicatorColor = Color.Transparent,
            unfocusedContainerColor = Color.Transparent,
            unfocusedTextColor = MaterialTheme.colorScheme.onSecondaryContainer
        ),
        singleLine = true
    )
}

@Composable
private fun StatModifier_TextField_IntegerInput(modifier: Modifier, text: String, labelText: String, onValueChangeEvent: (Int) -> Unit){
    val state = remember { mutableStateOf(text) }
    TextField(
        modifier = modifier.horizontalScroll(rememberScrollState()),
        value = state.value,
        onValueChange = { newText ->
            state.value = newText.replace(Regex("/^\\d+\$/"), "")
            onValueChangeEvent(Integer.parseInt(state.value))
        },
        label = { Text(labelText, fontSize = 10.sp) },
        textStyle = MaterialTheme.typography.labelSmall,
        colors = TextFieldDefaults.colors(
            unfocusedIndicatorColor = Color.Transparent,
            unfocusedContainerColor = Color.Transparent,
            unfocusedTextColor = MaterialTheme.colorScheme.onSecondaryContainer
        ),
        keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.NumberPassword),
        visualTransformation = VisualTransformation.None,
        singleLine = true
    )
}