package com.carsonmccombs.skillviewerfourcompose.stat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.carsonmccombs.skillviewerfourcompose.statmodifier_relationship.StatWithModifiers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class StatViewModel(private val dao: StatDao): ViewModel() {



    fun getStatName(id: Int): Flow<String> {
        return dao.getStatName(id = id)
    }
    fun getStat(id: Int): Flow<Stat> {
        return dao.getStat(id = id)
    }
    fun getStatIDs(): Flow<List<Int>> {
        return dao.getStatIDs()
    }

    fun getStatWithModifiers(statID: Int): Flow<StatWithModifiers>{
        return dao.getStatWithModifiers(statID)
    }


    fun getTotalStatModifiersValue(statID: Int): Flow<Int> {
        return dao.getTotalStatModifiersValue(statID)
    }


    fun onEvent(event: StatEvent){
        when (event){
            is StatEvent.Delete -> viewModelScope.launch { dao.delete(stat = event.stat) }
            is StatEvent.Upsert -> viewModelScope.launch { dao.upsert(stat = event.stat) }
            is StatEvent.DeleteStatModifier -> viewModelScope.launch { dao.deleteStatModifier(statModifier = event.statModifier) }
            is StatEvent.UpsertStatModifier -> viewModelScope.launch { dao.upsertStatModifier(statModifier = event.statModifier) }
        }
    }
}