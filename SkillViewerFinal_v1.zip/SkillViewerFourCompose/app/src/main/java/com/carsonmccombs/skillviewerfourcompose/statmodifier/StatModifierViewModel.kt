package com.carsonmccombs.skillviewerfourcompose.statmodifier

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

@Deprecated("Unneeded after transition to Relational Database. Information now stored and access through StatViewModel")
class StatModifierViewModel(private val dao: StatModifierDao): ViewModel() {

    private val _count = MutableStateFlow(0)
    val count = _count.asStateFlow()

    //private val _statIDs = MutableStateFlow<List<Int>>(emptyList())
    //val statIds: StateFlow<List<Int>> = _statIDs.asStateFlow()


    private val _data = MutableStateFlow<List<List<StatModifier>>>(emptyList())
    val data: StateFlow<List<List<StatModifier>>> = _data.asStateFlow()
}
    //init{
    //    viewModelScope.launch{
    //        dao.getStatIDs().collect{
    //            _statIDs.value = it
    //        }
    //    }
    //}

    /*
    fun getStatModifiers(statID: Int): Flow<List<StatModifier>> {
        return dao.getStatModifiersByStatID(statID)
    }
    fun getStatModifiers(statID: Int, id: Int): Flow<StatModifier> {
        return dao.getStatModifier(statID, id)
    }
    fun getStatModifierIDs(statID: Int): Flow<List<Int>>{
        return dao.getStatModifierIDs(statID)
    }

    fun getAllStatModifiers(): Flow<List<StatModifier>>{
        return dao.getAllStatModifiers()
    }




    fun onEvent(event: StatModifierEvent) {
        when (event) {
            is StatModifierEvent.Upsert -> viewModelScope.launch { dao.upsert(event.statModifier)  }
            is StatModifierEvent.Delete -> viewModelScope.launch { dao.delete(event.statModifier)  }
            is StatModifierEvent.New -> viewModelScope.launch {
                Log.d("Twab","EVENT ID: ${event.statID}")
                dao.upsert(StatModifier(statID = event.statID))
            }
        }
    }


}*/
/*
data class StatState(
    val count: Int,
    val list: List<List<StatModifier>>
)*/