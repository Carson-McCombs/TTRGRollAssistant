package com.carsonmccombs.skillviewerfourcompose.statmodifier

@Deprecated("Unneeded after transition to relational database, check out StatEvent instead.")
sealed interface StatModifierEvent{
    data class Delete(val statModifier: StatModifier): StatModifierEvent
    data class Upsert(val statModifier: StatModifier): StatModifierEvent
    data class New(val statID: Int): StatModifierEvent


}