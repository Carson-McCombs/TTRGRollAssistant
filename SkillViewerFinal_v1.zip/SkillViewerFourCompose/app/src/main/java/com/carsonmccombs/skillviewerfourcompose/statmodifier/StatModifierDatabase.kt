package com.carsonmccombs.skillviewerfourcompose.statmodifier

import androidx.room.Database
import androidx.room.RoomDatabase


@Deprecated("Unneeded after transition to relational database, check out StatDatabase instead.")
@Database(entities = [StatModifier::class], version = 7, exportSchema = false)
abstract class StatModifierDatabase: RoomDatabase() {
    abstract val dao: StatModifierDao
}